# **How To Create A Custom Skin Pack For From The Fog**

# A simple guide on how to make a custom skin pack for From The Fog!

1. Change the textures in "assets/watching/textures/item/herobrine/custom" to the skins you want. (Optionally you can change the models aswell in "assets/watching/models/item/herobrine/custom")

2. Change the icons for the skins in "assets/watching/textures/font/watching_ui/icons/skins/custom" to match the skins you made.

3. Change the name of the skin pack and the names of the skins in all of the files at "assets/minecraft/lang."

4. Change the pack icon and description to whatever you want and apply it to your game! If you want to show off your hard work feel free to post it in "#addon-showcase" in our [**Official Discord**!](https://discord.lunareclipse.studio)

## **Tips**

- The "_emissive" layers are the same as the normal layers, but they glow.

- Erase any parts of the normal skin that you make emissive.

- Use "/function watching:events/sightings/creeping" and look behind you to test the skins.